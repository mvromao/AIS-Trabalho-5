package activiti;

import java.io.IOException;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

import support.WeatherAPI;

public class getTempActiviti implements JavaDelegate { 

	public void execute(DelegateExecution execution) { 
	WeatherAPI wAPI = new WeatherAPI();
	String key =  "cc27c0c0a5eae4910e14fd2cbbf77ebc";
	String city = "Almada,PT";
	String unit = "metric";
	String language = "pt";

	Double temp = -1.0;
	try {
		temp = wAPI.getTemp(key,city,unit,language);
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("Temperatura em "+city+": " + temp.toString());
	
	execution.setVariable("temperaturaexterior", temp); 
} 
} 
