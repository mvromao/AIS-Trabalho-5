package activiti;

import java.io.File;       // Import the File class
import java.io.IOException; // Import IOException to handle errors

import org.activiti.engine.delegate.DelegateExecution;
import org.json.simple.JSONObject;
public class sendDataFromFile {
	
	public void execute(DelegateExecution execution) { 
		String nameUser;
		float comfortTemp;
		float houseTemp;
	    
		comfortTemp = (float)execution.getVariable("temperaturadeconforto");
	    nameUser = (String)execution.getVariable("nomeutilizador");
	    houseTemp = (float)execution.getVariable("temperaturadacasa") 
	    
	    
	    try {
	      File myObj = new File("JSON_Data.txt"); // Create File object
	      System.out.println("File created: " + myObj.getName());
	      if (myObj.createNewFile()) {           // Try to create the file
	      } else {
	        System.out.println("File already exists.");
	      }
	    } catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace(); // Print error details
	    }
	}
}
